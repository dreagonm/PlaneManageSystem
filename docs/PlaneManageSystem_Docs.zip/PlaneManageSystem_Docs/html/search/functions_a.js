var searchData=
[
  ['newairline_215',['NewAirLine',['../class_tickets.html#a08e50a3ed049acf81314d43460033899',1,'Tickets::NewAirLine(std::string AirlineID)'],['../class_tickets.html#a410ee9519e0c7a26abe3eb1d04d69ab0',1,'Tickets::NewAirLine(std::string AirlineID, std::vector&lt; std::string &gt; Seats, std::vector&lt; std::string &gt; SeatLevel)']]],
  ['newtable_216',['NewTable',['../class_data___base.html#a9c1b08480e6dd7bde001fa59f4ec7d11',1,'Data_Base::NewTable(std::string TableName)'],['../class_data___base.html#a6b2e3fa03ab359b4df09e7669bcf766a',1,'Data_Base::NewTable(std::string TableName, std::vector&lt; std::string &gt; _Fields)']]]
];

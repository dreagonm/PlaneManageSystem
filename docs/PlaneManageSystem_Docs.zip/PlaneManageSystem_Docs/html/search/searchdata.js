var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvw~",
  1: "adrtuw",
  2: "bcdfms",
  3: "abcdefgilmnoqrstuvw~",
  4: "adfgimprstu",
  5: "acdhps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "文件",
  3: "函数",
  4: "变量",
  5: "宏定义"
};


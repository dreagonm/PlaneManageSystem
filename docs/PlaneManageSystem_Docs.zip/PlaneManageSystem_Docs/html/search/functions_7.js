var searchData=
[
  ['initwork_208',['InitWork',['../class_worker.html#a9bba3b7b45aa447a94695fa6d250b292',1,'Worker']]]
];

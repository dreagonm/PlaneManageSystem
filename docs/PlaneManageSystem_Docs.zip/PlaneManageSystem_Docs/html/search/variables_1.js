var searchData=
[
  ['data_249',['Data',['../class_record.html#aabdba773e3d6edec1bc6b5e7523e7112',1,'Record']]]
];

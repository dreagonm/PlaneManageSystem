var searchData=
[
  ['fields_51',['Fields',['../class_record.html#aac84f88cefe8fc2aee0f2731db88f498',1,'Record::Fields()'],['../class_table.html#a23934f7c1851081933e2d6d61fb3da2a',1,'Table::Fields()']]],
  ['filterforrecord_52',['FilterForRecord',['../class_table.html#a205381687d9c914535cbef891135d61f',1,'Table::FilterForRecord(std::string _Field, std::string _Val)'],['../class_table.html#a80cb7a6c218fb72dc8f73ba799c2fd69',1,'Table::FilterForRecord(std::vector&lt; std::string &gt; _Fields, std::vector&lt; std::string &gt; _Vals)']]],
  ['filterforrecords_53',['FilterForRecords',['../class_table.html#abd1050ab904cf9d22440e2922f7a87b2',1,'Table']]],
  ['frontend_2ecpp_54',['frontend.cpp',['../frontend_8cpp.html',1,'']]],
  ['frontend_2eh_55',['frontend.h',['../frontend_8h.html',1,'']]]
];

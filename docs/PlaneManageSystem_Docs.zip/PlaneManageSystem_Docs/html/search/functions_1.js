var searchData=
[
  ['bool_5fdeserializer_170',['Bool_DeSerializer',['../backend_8cpp.html#a2c91810b108644faa1bc460be4f1fe02',1,'Bool_DeSerializer(std::string x):&#160;backend.cpp'],['../backend_8h.html#a2c91810b108644faa1bc460be4f1fe02',1,'Bool_DeSerializer(std::string x):&#160;backend.cpp']]],
  ['bool_5fserializer_171',['Bool_Serializer',['../backend_8cpp.html#a70bb593dd008eb7a69c380a53406d8db',1,'Bool_Serializer(bool t):&#160;backend.cpp'],['../backend_8h.html#a70bb593dd008eb7a69c380a53406d8db',1,'Bool_Serializer(bool t):&#160;backend.cpp']]]
];

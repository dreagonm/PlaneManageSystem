var searchData=
[
  ['userlogin_5f_263',['UserLogin_',['../frontend_8cpp.html#af9d473cbc7bc258a712b46f66dbf3969',1,'UserLogin_():&#160;frontend.cpp'],['../frontend_8h.html#af9d473cbc7bc258a712b46f66dbf3969',1,'UserLogin_():&#160;frontend.cpp']]],
  ['usertickets_5f_264',['UserTickets_',['../frontend_8cpp.html#a0030e36012803e729cb5848383fd3d35',1,'frontend.cpp']]],
  ['uuidpool_265',['UUIDpool',['../backend_8cpp.html#a320eb6e60cd0b12070e559ce89b7bdbb',1,'UUIDpool():&#160;backend.cpp'],['../backend_8h.html#a320eb6e60cd0b12070e559ce89b7bdbb',1,'UUIDpool():&#160;backend.cpp']]]
];

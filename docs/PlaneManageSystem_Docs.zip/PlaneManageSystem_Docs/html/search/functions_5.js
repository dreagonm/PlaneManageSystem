var searchData=
[
  ['filterforrecord_192',['FilterForRecord',['../class_table.html#a205381687d9c914535cbef891135d61f',1,'Table::FilterForRecord(std::string _Field, std::string _Val)'],['../class_table.html#a80cb7a6c218fb72dc8f73ba799c2fd69',1,'Table::FilterForRecord(std::vector&lt; std::string &gt; _Fields, std::vector&lt; std::string &gt; _Vals)']]],
  ['filterforrecords_193',['FilterForRecords',['../class_table.html#abd1050ab904cf9d22440e2922f7a87b2',1,'Table']]]
];

var searchData=
[
  ['fields_250',['Fields',['../class_record.html#aac84f88cefe8fc2aee0f2731db88f498',1,'Record::Fields()'],['../class_table.html#a23934f7c1851081933e2d6d61fb3da2a',1,'Table::Fields()']]]
];

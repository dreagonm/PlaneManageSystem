var searchData=
[
  ['globalorderid_251',['GlobalOrderID',['../backend_8cpp.html#aeceb4d256bfe6854843ba9eac55a6e47',1,'GlobalOrderID():&#160;backend.cpp'],['../backend_8h.html#aeceb4d256bfe6854843ba9eac55a6e47',1,'GlobalOrderID():&#160;backend.cpp']]]
];

var searchData=
[
  ['serializer_224',['Serializer',['../backend_8cpp.html#a6aae3a52ff4330dd6365e99767f3d512',1,'Serializer(int x):&#160;backend.cpp'],['../backend_8h.html#a6aae3a52ff4330dd6365e99767f3d512',1,'Serializer(int x):&#160;backend.cpp']]]
];

var searchData=
[
  ['querystatus_93',['QueryStatus',['../class_user_login.html#ae65ab602e3d0b5375e9cfd54b0eeb5bd',1,'UserLogin']]]
];

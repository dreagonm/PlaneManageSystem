var searchData=
[
  ['tables_261',['Tables',['../class_data___base.html#a0e5a7b9c9483accad109de6ea43d6b12',1,'Data_Base']]],
  ['tickets_5f_262',['Tickets_',['../frontend_8cpp.html#a87a0aa5e2ec4687ed55e5b5a2e24b518',1,'frontend.cpp']]]
];

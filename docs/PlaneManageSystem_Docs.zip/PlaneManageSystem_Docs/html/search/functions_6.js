var searchData=
[
  ['generateorderid_194',['GenerateOrderID',['../class_tickets.html#ac156e112d2270a2b9c0f59bc447a23dd',1,'Tickets']]],
  ['getairline_195',['GetAirline',['../class_airline_table.html#a7bc118051a630bd25f3485dc185d9f8d',1,'AirlineTable::GetAirline(void)'],['../class_airline_table.html#a0f2f85519bf47daf13ec02008dbf066d',1,'AirlineTable::GetAirline(std::string AirlineID)']]],
  ['getallfields_196',['GetAllFields',['../class_record.html#a30cf81cd8ce456292b1cbb1132d65157',1,'Record::GetAllFields()'],['../class_table.html#a3be0b0874adb8f3c0c02c5ecf2233c2f',1,'Table::GetAllFields()']]],
  ['getallrecordswithoutspecialfield_197',['GetAllRecordsWithoutSpecialField',['../class_table.html#ae9176d6527d2f50752a9912b508ed8da',1,'Table']]],
  ['getallrecordswithspecialfield_198',['GetAllRecordsWithSpecialField',['../class_table.html#a2a287bdf07e2a84b42f70c7388203440',1,'Table']]],
  ['getallrecordswithspecialfields_199',['GetAllRecordsWithSpecialFields',['../class_table.html#a37d7e2a9ccad7a2bec2dc8374fad9c57',1,'Table']]],
  ['getlastestrecord_200',['GetLastestRecord',['../class_table.html#a16136735c5600a715d96e207febf9ee1',1,'Table']]],
  ['getorderid_201',['GetOrderID',['../class_user_tickets.html#a5a6bc5920095f241769b5a9d6e96c89e',1,'UserTickets']]],
  ['getrecord_202',['GetRecord',['../class_table.html#a710cf722b57807a043bf24dfa81fc63d',1,'Table::GetRecord(int pk)'],['../class_table.html#ad4ce45529d968c6054bd902aff5a5ac0',1,'Table::GetRecord(std::vector&lt; std::string &gt; _SrcFields, std::vector&lt; std::string &gt; _SrcVals)']]],
  ['getrecordfield_203',['GetRecordField',['../class_record.html#a9978854405cad4cdcf97797ae0869f31',1,'Record::GetRecordField()'],['../class_table.html#a594594ed3fec989264e35e5b24b0640f',1,'Table::GetRecordField(int pk, std::string _Field)'],['../class_table.html#ac8f7c802398e086a646a6aba0a359ffb',1,'Table::GetRecordField(std::vector&lt; std::string &gt; _SrcFields, std::vector&lt; std::string &gt; _SrcVals, std::string _Field)']]],
  ['getrecordfields_204',['GetRecordFields',['../class_table.html#a560b1167e2a276cff17175ce3bb3a3d2',1,'Table::GetRecordFields(int pk, std::vector&lt; std::string &gt; _Fields)'],['../class_table.html#aeab0e4ef46211f3b4ce41da0b7ba928f',1,'Table::GetRecordFields(std::vector&lt; std::string &gt; _SrcFields, std::vector&lt; std::string &gt; _SrcVals, std::vector&lt; std::string &gt; _Fields)']]],
  ['getremain_205',['GetRemain',['../class_tickets.html#a64783eba8f9496dfe93d318639477f70',1,'Tickets']]],
  ['getseat_206',['GetSeat',['../class_tickets.html#aef0f7d172459887857e62f9a8606e2e0',1,'Tickets']]],
  ['getusername_207',['GetUserName',['../class_user_login.html#ac05fbc81f669abad7516813d0828f3c7',1,'UserLogin']]]
];

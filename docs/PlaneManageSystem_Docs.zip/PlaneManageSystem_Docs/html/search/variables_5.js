var searchData=
[
  ['myuuid_256',['myUUID',['../class_worker.html#a810bb5cd57f2ec1771a697b7489c2f7a',1,'Worker']]]
];

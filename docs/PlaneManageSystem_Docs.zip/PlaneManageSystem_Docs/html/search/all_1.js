var searchData=
[
  ['backend_2ecpp_18',['backend.cpp',['../backend_8cpp.html',1,'']]],
  ['backend_2eh_19',['backend.h',['../backend_8h.html',1,'']]],
  ['bool_5fdeserializer_20',['Bool_DeSerializer',['../backend_8cpp.html#a2c91810b108644faa1bc460be4f1fe02',1,'Bool_DeSerializer(std::string x):&#160;backend.cpp'],['../backend_8h.html#a2c91810b108644faa1bc460be4f1fe02',1,'Bool_DeSerializer(std::string x):&#160;backend.cpp']]],
  ['bool_5fserializer_21',['Bool_Serializer',['../backend_8cpp.html#a70bb593dd008eb7a69c380a53406d8db',1,'Bool_Serializer(bool t):&#160;backend.cpp'],['../backend_8h.html#a70bb593dd008eb7a69c380a53406d8db',1,'Bool_Serializer(bool t):&#160;backend.cpp']]]
];

var searchData=
[
  ['worker_122',['Worker',['../class_worker.html',1,'Worker'],['../class_worker.html#a3754817df06ffe220f7f0d903c78ccac',1,'Worker::Worker()']]],
  ['wrapper_123',['Wrapper',['../backend_8cpp.html#a84c7171305800c9516547fc8e81df72e',1,'Wrapper(T x):&#160;backend.cpp'],['../backend_8h.html#a84c7171305800c9516547fc8e81df72e',1,'Wrapper(T x):&#160;backend.cpp']]]
];

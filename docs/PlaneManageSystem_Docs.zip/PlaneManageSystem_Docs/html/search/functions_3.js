var searchData=
[
  ['data_5fbase_176',['Data_Base',['../class_data___base.html#a62938c958287e60e99fdac18c3513db6',1,'Data_Base::Data_Base()'],['../class_data___base.html#a967841ea8ecb4e5b4432557229958ffe',1,'Data_Base::Data_Base(const Data_Base &amp;rhs)']]],
  ['deseiralizer_177',['DeSeiralizer',['../backend_8cpp.html#a0effd59b5ecaadfe261ffb274fdc4682',1,'backend.cpp']]],
  ['deserializer_178',['DeSerializer',['../backend_8h.html#af6ddc80d900dac583aa441bc19b53ea6',1,'backend.h']]]
];

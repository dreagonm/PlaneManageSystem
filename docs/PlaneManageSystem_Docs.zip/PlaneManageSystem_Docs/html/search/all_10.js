var searchData=
[
  ['saver_2ecpp_98',['saver.cpp',['../saver_8cpp.html',1,'']]],
  ['saver_2eh_99',['saver.h',['../saver_8h.html',1,'']]],
  ['searchrecord_100',['SearchRecord',['../class_table.html#aab59f9703fc775a2e5f00ed460bf2889',1,'Table']]],
  ['serializer_101',['Serializer',['../backend_8cpp.html#a6aae3a52ff4330dd6365e99767f3d512',1,'Serializer(int x):&#160;backend.cpp'],['../backend_8h.html#a6aae3a52ff4330dd6365e99767f3d512',1,'Serializer(int x):&#160;backend.cpp']]],
  ['serializer_2ecpp_102',['serializer.cpp',['../serializer_8cpp.html',1,'']]],
  ['serializer_2eh_103',['serializer.h',['../serializer_8h.html',1,'']]],
  ['stringify_104',['STRINGIFY',['../_c_make_c_compiler_id_8c.html#a43e1cad902b6477bec893cb6430bd6c8',1,'STRINGIFY():&#160;CMakeCCompilerId.c'],['../_c_make_c_x_x_compiler_id_8cpp.html#a43e1cad902b6477bec893cb6430bd6c8',1,'STRINGIFY():&#160;CMakeCXXCompilerId.cpp']]],
  ['stringify_5fhelper_105',['STRINGIFY_HELPER',['../_c_make_c_compiler_id_8c.html#a2ae9b72bb13abaabfcf2ee0ba7d3fa1d',1,'STRINGIFY_HELPER():&#160;CMakeCCompilerId.c'],['../_c_make_c_x_x_compiler_id_8cpp.html#a2ae9b72bb13abaabfcf2ee0ba7d3fa1d',1,'STRINGIFY_HELPER():&#160;CMakeCXXCompilerId.cpp']]]
];
